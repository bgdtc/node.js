var assert = require('assert');

describe('Multiplication', function(){
    // OK
    it('should work', function(){
        assert.strictEqual(2*3, 6);
    });
});