
/*
 * Controller
 *************/ 
module.exports = {
    // Method Get
    get: (req, res) => {
        res.render('contact')
    }
}